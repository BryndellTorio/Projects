#include "Arduino.h"
#include <Adafruit_PWMServoDriver.h>
#include <stdint.h>

#define SERVO_TURN_RIGHT 328
#define SERVO_TURN_LEFT 650
#define SERVO_DEFAULT_POSITION 485

#define RELAY_1 5
#define RELAY_2 6
#define RELAY_3 7
#define CONVEYOR 11

#define PROXY_LARGE A0
#define PROXY_MEDIUM A1
#define PROXY_SMALL A2

#define S0_PIN 3
#define S1_PIN 2
#define S2_PIN 9
#define S3_PIN 8
#define COLSEN_OUT 4

Adafruit_PWMServoDriver pwm = Adafruit_PWMServoDriver(0x40);

void setup() {
  pwm.begin();
  pwm.setPWMFreq(60);
  Serial.begin(9600);
  Serial.println("Ready!");

  pinMode(RELAY_1, OUTPUT);
  pinMode(RELAY_2, OUTPUT);
  pinMode(RELAY_3, OUTPUT);
  pinMode(CONVEYOR, OUTPUT);

  pinMode(PROXY_LARGE, INPUT);
  pinMode(PROXY_MEDIUM, INPUT);
  pinMode(PROXY_SMALL, INPUT);

  pinMode(S0_PIN, OUTPUT);
  pinMode(S1_PIN, OUTPUT);
  pinMode(S2_PIN, OUTPUT);
  pinMode(S3_PIN, OUTPUT);
  pinMode(COLSEN_OUT, INPUT);

  /* Color Sensor: Set pulse width to 20% as per datasheet */
  digitalWrite(S0_PIN, HIGH);
  digitalWrite(S1_PIN, LOW);
}

// Custom definitions
unsigned int systemCounter = 0;

int process_red_value() {
  digitalWrite(S2_PIN, LOW);
  digitalWrite(S3_PIN, LOW);
  int pulse_length = pulseIn(COLSEN_OUT, LOW);
  return pulse_length;
}

int process_green_value() {
  digitalWrite(S2_PIN, HIGH);
  digitalWrite(S3_PIN, HIGH);
  int pulse_length = pulseIn(COLSEN_OUT, LOW);
  return pulse_length;
}

int process_blue_value() {
  digitalWrite(S2_PIN, LOW);
  digitalWrite(S3_PIN, HIGH);
  int pulse_length = pulseIn(COLSEN_OUT, LOW);
  return pulse_length;
}

void system() {
  int r, g, b;
  r = process_red_value();
  delay(200);
  g = process_green_value();
  delay(200);
  b = process_blue_value();
  delay(200);

  /* NOTE: Used to calibrate the color sensor. */
  /* Serial.println("r = " + String(r) + "\tb = " + String(b) + */
  /*                "\tg = " + String(g)); */

  if (r <= 170 && r >= 50 && b >= 115 && b <= 200 && g >= 120 && g <= 200) {
    Serial.println("Color Red!");
  } else if (r <= 220 && b <= 190 && g <= 190 && r >= 170 && b >= 90 &&
             g >= 90) {
    Serial.println("Color Blue!");
  }
}

void loop() {
  systemCounter++;
  system();
  if (Serial.available()) {
    String cmd = Serial.readString();
    Serial.println("INPUT: " + cmd);

    if (cmd == "R1") {
      pwm.setPWM(0, 0, SERVO_DEFAULT_POSITION);
      pwm.setPWM(1, 0, SERVO_TURN_RIGHT);
      Serial.println("Box 1 colored Red.");
    } else if (cmd == "B1") {
      pwm.setPWM(0, 0, SERVO_TURN_LEFT);
      pwm.setPWM(1, 0, SERVO_DEFAULT_POSITION);
      Serial.println("Box 1 colored Blue.");
    } else if (cmd == "G1") {
      pwm.setPWM(0, 0, SERVO_DEFAULT_POSITION);
      pwm.setPWM(1, 0, SERVO_DEFAULT_POSITION);
      Serial.println("Box 1 colored Green.");
    } else if (cmd == "R2") {
      pwm.setPWM(2, 0, SERVO_DEFAULT_POSITION);
      pwm.setPWM(3, 0, SERVO_TURN_RIGHT);
      Serial.println("Box 1 colored Red.");
    } else if (cmd == "B2") {
      pwm.setPWM(2, 0, SERVO_TURN_LEFT);
      pwm.setPWM(3, 0, SERVO_DEFAULT_POSITION);
      Serial.println("Box 1 colored Blue.");
    } else if (cmd == "G2") {
      pwm.setPWM(2, 0, SERVO_DEFAULT_POSITION);
      pwm.setPWM(3, 0, SERVO_DEFAULT_POSITION);
      Serial.println("Box 1 colored Green.");
    } else if (cmd == "R3") {
      pwm.setPWM(4, 0, SERVO_DEFAULT_POSITION);
      pwm.setPWM(5, 0, SERVO_TURN_RIGHT);
      Serial.println("Box 1 colored Red.");
    } else if (cmd == "B3") {
      pwm.setPWM(4, 0, SERVO_TURN_LEFT);
      pwm.setPWM(5, 0, SERVO_DEFAULT_POSITION);
      Serial.println("Box 1 colored Blue.");
    } else if (cmd == "G3") {
      pwm.setPWM(4, 0, SERVO_DEFAULT_POSITION);
      pwm.setPWM(5, 0, SERVO_DEFAULT_POSITION);
      Serial.println("Box 1 colored Green.");
    } else if (cmd == "OFF") {
      pwm.setPWM(0, 0, SERVO_DEFAULT_POSITION);
      pwm.setPWM(1, 0, SERVO_DEFAULT_POSITION);
      pwm.setPWM(2, 0, SERVO_DEFAULT_POSITION);
      pwm.setPWM(3, 0, SERVO_DEFAULT_POSITION);
      pwm.setPWM(4, 0, SERVO_DEFAULT_POSITION);
      pwm.setPWM(5, 0, SERVO_DEFAULT_POSITION);
      Serial.println("OFF turned servo.");
      Serial.println("turned off.");
    } else if (cmd == "CONVON") {
      digitalWrite(CONVEYOR, HIGH);
      Serial.println("Turning on Conveyor.");
    } else if (cmd == "CONVOFF") {
      digitalWrite(CONVEYOR, LOW);
      Serial.println("Turning off Conveyor.");
    } else if (cmd == "PUMP1ON") {
      digitalWrite(RELAY_1, HIGH);
      Serial.println("Turn on Pump 1.");
    } else if (cmd == "PUMP1OFF") {
      digitalWrite(RELAY_1, LOW);
      Serial.println("Turn off Pump 1.");
    } else if (cmd == "PUMP2ON") {
      digitalWrite(RELAY_2, HIGH);
      Serial.println("Turn on Pump 2.");
    } else if (cmd == "PUMP2OFF") {
      digitalWrite(RELAY_2, LOW);
      Serial.println("Turn off Pump 2.");
    } else if (cmd == "PUMP3ON") {
      digitalWrite(RELAY_3, HIGH);
      Serial.println("Turn on Pump 3.");
    } else if (cmd == "PUMP3OFF") {
      digitalWrite(RELAY_3, LOW);
      Serial.println("Turn off Pump 3.");
    } else if (cmd == "PUMPALLON") {
      digitalWrite(RELAY_1, HIGH);
      digitalWrite(RELAY_2, HIGH);
      digitalWrite(RELAY_3, HIGH);
      Serial.println("Turn on all pump.");
    } else if (cmd == "PUMPALLOFF") {
      digitalWrite(RELAY_1, LOW);
      digitalWrite(RELAY_2, LOW);
      digitalWrite(RELAY_3, LOW);
      Serial.println("Turn off all pump.");
    } else if (cmd.startsWith("SERVO1=")) {
      int cmdIndex1 = cmd.indexOf('=');
      cmd.remove(0, cmdIndex1 + 1);
      pwm.setPWM(0, 0, cmd.toInt());
      Serial.println("1st servo set to " + String(cmd));
      delay(200);
    } else {
      Serial.println("Command not recognized.");
    }
  }
  delay(1);
}
